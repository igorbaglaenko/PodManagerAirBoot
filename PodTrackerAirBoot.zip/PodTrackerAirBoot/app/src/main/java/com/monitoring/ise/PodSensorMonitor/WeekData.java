package com.monitoring.ise.PodSensorMonitor;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class WeekData {
    public float[] steps;
    public float[] alarms;
    public Calendar weekStart;
    public Calendar weekEnd;


    private Calendar firstDay;
    private int weekNumber;
    public WeekData(int year, int day ) {
        firstDay =  new GregorianCalendar();
        firstDay.set(Calendar.YEAR, year);
        firstDay.set(Calendar.DAY_OF_YEAR, day);
        steps = new float[7];
        alarms = new float[7];

    }

    public void setWeekDays(int[] dataSteps, int[] dataAlarms, int weekNo) {
        weekStart = firstDay;
        weekStart.add(Calendar.DAY_OF_YEAR, weekNo * 7);
        weekEnd = weekStart;
        weekEnd.add(Calendar.DAY_OF_YEAR, 7);
        int j = weekNo * 7;
        for(int i = 0; i < 7; i++) {
            steps[i] = (float)dataSteps[j];
            alarms[i] = (float)dataAlarms[j];
            j++;
        }
    }
}
