package com.monitoring.ise.PodSensorMonitor;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.ColorStateList;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class BootStrapsActivity extends AppCompatActivity {

    private short backWeight;
    private short frontWeight;
    private short minbackWeight;
    private short minfrontWeight;
    private int   frontStrap;
    private int   backStrap;

    private boolean stopReading = false;

    public TextView frontTension;
    public TextView backTension;
    public TextView tensionTitle;
    public Button actionButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_boot_straps);

        frontTension = findViewById(R.id.view_front_tension);
        backTension = findViewById(R.id.view_back_tension);
        tensionTitle = findViewById(R.id.label_tension_prompt);
        actionButton = findViewById(R.id.button_OK);

        frontTension.setText("-");
        backTension.setText("-");
        tensionTitle.setText("Apply sitting weight on Boot.\nStart tighten up with Ankle Strap");
        actionButton.setEnabled(false);

        registerReceiver(mBleServiceReceiver, makeGattUpdateIntentFilter());

    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(mBleServiceReceiver);
    }
    // START: Receiving POD data
    private static IntentFilter makeGattUpdateIntentFilter() {
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(SoleSensorBleService.CALIBRATE_DATA_NOTIFY);
        intentFilter.addAction(SoleSensorBleService.ACTION_GATT_DISCONNECTED);

        return intentFilter;
    }
    private BroadcastReceiver mBleServiceReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
                 if (SoleSensorBleService.CALIBRATE_DATA_NOTIFY   .equals(action)) {
                byte[] ar = intent.getByteArrayExtra(SoleSensorBleService.CALIBRATE_DATA_AVAILABLE);
                if (ar[0] == 0x43) {
                    if(!stopReading) {
                        ByteBuffer bb = ByteBuffer.wrap(ar);
                        bb.order(ByteOrder.LITTLE_ENDIAN);
                        bb.position(7);
                        // Update parameters view
                        backWeight = bb.getShort();
                        frontWeight = bb.getShort();
                        minbackWeight = bb.getShort();
                        minfrontWeight = bb.getShort();
                        if(frontWeight > (minfrontWeight*3) / 2)
                            frontStrap = 1;
                        else if(frontWeight < minfrontWeight / 2)
                            frontStrap = -1;
                        else
                            frontStrap = 0;
                        if(backWeight > (minbackWeight*3) / 2)
                            backStrap = 1;
                        else if(backWeight < minbackWeight / 2)
                            backStrap = -1;
                        else
                            backStrap = 0;
                        updateMessage();
                    }

                }
            }
            else if (SoleSensorBleService.ACTION_GATT_DISCONNECTED.equals(action)) {
                     finish();
                }
        }

    };
    private void updateMessage( ) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                String message = "";
                if(frontStrap == 1) {
                    frontTension.setTextColor(0xffd81b60);
                    frontTension.setText("too TIGHT");
                }
                else if (frontStrap == -1) {
                    frontTension.setTextColor(0xffd81b60);
                    frontTension.setText("too LOOSE");
                }
                else {
                    frontTension.setTextColor(0xff008520);
                    frontTension.setText("OK");
                }
                if(backStrap == 1) {
                    backTension.setTextColor(0xffd81b60);
                    backTension.setText("too TIGHT");
                }
                else if (backStrap == -1) {
                    backTension.setTextColor(0xffd81b60);
                    backTension.setText("too LOOSE");
                }
                else {
                    backTension.setTextColor(0xff008520);
                    backTension.setText("OK");
                }
                if(frontStrap == 0 && backStrap == 0)
                {
//                    new Handler().postDelayed(new Runnable() {
//                        @Override
//                        public void run() {
//                            setResult(MainMonitorActivity.RESPONSE_CALIBRATE_DATA);
//                            finish();
//                        }
//                    }, 1000);
                    actionButton.setEnabled(true);
                }
                else {
                    actionButton.setEnabled(false);
                }
//                    stopReading = false;
//                frontTension.setText(message);
            }
        });
    }

    public void onClickButtonAction(View view) {
        setResult(MainMonitorActivity.RESPONSE_CALIBRATE_DATA);
        finish();
    }

}
