package com.monitoring.ise.PodSensorMonitor;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

public class WeightGauge extends View {

    private Paint arcPaint;
    int arcCenterX;
    int arcCenterY;
    int mGaugePosition;
    float alarmMargin;

    public WeightGauge(Context context) {
        super(context);
        initialize();
    }

    public WeightGauge(Context context, AttributeSet attrs) {
        super(context, attrs);
        TypedArray a = context.getTheme().obtainStyledAttributes(
                attrs,
                R.styleable.WeightGauge,
                0, 0);

        try {
            mGaugePosition = a.getInteger(R.styleable.WeightGauge_gaugePosition, 0);
        } finally {
            a.recycle();
        }
        initialize();
    }

    public WeightGauge(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initialize();
    }

    private void initialize() {
        arcPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        arcPaint.setStyle(Paint.Style.STROKE);
        arcPaint.setStrokeWidth(15f);
        alarmMargin = 67.5f;
    }

    public void setAlarmMargin(float marginPercent) {
        float margin = 90f * marginPercent;
        if(alarmMargin != margin)
        {
            alarmMargin = margin;
            invalidate();
        }
    }
    @Override
    protected void onDraw(Canvas canvas) {
        int width = canvas.getWidth();
        int height = canvas.getHeight();
        final RectF arcBounds;
        int startXstroke;
        int startYstroke;
        arcPaint.setStrokeWidth(15f);
        int arcWidth = width - 10 - 55;
        if(mGaugePosition == 0) {
            arcCenterX = width - 10;
            arcCenterY = height - 10;
            startXstroke = arcCenterX - arcWidth - 20;
            startYstroke = arcCenterY;
        } else {
            arcCenterX = 10;
            arcCenterY = height - 10;
            startXstroke = arcCenterX;
            startYstroke = arcCenterY - arcWidth - 20;
        }
        arcBounds = new RectF(arcCenterX - arcWidth, arcCenterY - arcWidth, arcCenterX + arcWidth, arcCenterY + arcWidth);


        // Draw the arc
        //canvas.drawArc(arcBounds, 180f, 20f, false, arcPaint);

        if(mGaugePosition == 0) {
            arcPaint.setColor(Color.GREEN);
            canvas.drawArc(arcBounds, 180f, alarmMargin, false, arcPaint);
            arcPaint.setColor(Color.RED);
            canvas.drawArc(arcBounds, 180f + alarmMargin, 90f - alarmMargin, false, arcPaint);
        } else {
            arcPaint.setColor(Color.RED);
            canvas.drawArc(arcBounds, -90f, 90f - alarmMargin, false, arcPaint);
            arcPaint.setColor(Color.GREEN);
            canvas.drawArc(arcBounds, -alarmMargin, alarmMargin, false, arcPaint);

        }
        // Draw the pointers
        final int totalNoOfPointers = 20;
        final int pointerMaxHeight = 25;
        final int pointerMinHeight = 15;

        arcPaint.setStrokeWidth(5f);
        arcPaint.setStrokeCap(Paint.Cap.ROUND);
        arcPaint.setColor(Color.DKGRAY);
        int pointerHeight;
        for (int i = 0; i <= totalNoOfPointers; i++) {
            if(i%5 == 0){
                pointerHeight = pointerMaxHeight;
            }else{
                pointerHeight = pointerMinHeight;
            }
            if(mGaugePosition == 0) {
                canvas.drawLine(startXstroke, startYstroke, startXstroke - pointerHeight, startYstroke, arcPaint);
            } else {
                canvas.drawLine(startXstroke, startYstroke, startXstroke, startYstroke - pointerHeight, arcPaint);
            }

            canvas.rotate(90f/totalNoOfPointers, arcCenterX, arcCenterY);
        }
    }


}

