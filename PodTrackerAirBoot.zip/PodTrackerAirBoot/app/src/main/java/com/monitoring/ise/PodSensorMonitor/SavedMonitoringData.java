package com.monitoring.ise.PodSensorMonitor;

import android.content.Context;
import android.util.Log;

import java.io.FileInputStream;
import java.io.InvalidClassException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class SavedMonitoringData implements Serializable {
    public static final String patientDataFile = "MonitoringData.dat";
    public static final int TotalDataDays = 121;
    // setup information
    protected String deviceAddress;
    protected int    bodyWeight;
    protected int    weightAdjustment;
    protected int    totalThreshold;
    protected int    backThreshold;
    protected int    frontThreshold;
    protected int    injuryType;
    protected int    alertsNo;
    protected String emailAddr;
    protected byte[] data24hrs;
    protected byte[] data123days;

    public SavedMonitoringData( ) {
        deviceAddress = "";
        bodyWeight = 0;
        weightAdjustment = 0;
        totalThreshold = 0;
        backThreshold = 0;
        frontThreshold = 0;
        injuryType = 0;
        alertsNo = 0;
        emailAddr = "";
        data24hrs = new byte[98];
        Arrays.fill(data24hrs,(byte) 0);
        data123days = new byte[TotalDataDays*4 + 8];
        Arrays.fill(data123days, (byte)0);
    }
    public void set123daysData(byte[] data) {
        data123days = data.clone();
    }
    public void set24hrsData(byte[] data) {
        data24hrs = data.clone();
    }
    public void clear123daysData() {
        Arrays.fill(data123days, (byte)0);
    }
    public void clear24hrsData() {
        Arrays.fill(data24hrs,(byte) 0);
    }
}
