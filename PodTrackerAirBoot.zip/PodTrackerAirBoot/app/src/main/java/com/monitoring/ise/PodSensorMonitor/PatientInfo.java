package com.monitoring.ise.PodSensorMonitor;

import android.util.Log;

import java.io.File;
import java.io.FileInputStream;
import java.io.Serializable;
import java.nio.ByteBuffer;

public class PatientInfo implements Serializable {
    public static final String patientFileName = "PODProfile.dat";
    public int size;
    public int request;    // 0 - invalid; 1 - update; 2 - initialize
    public int bodyWeight;
    public int weightCorrection;
    public int totalThreshold;
    public int backThreshold;
    public int frontThreshold;
    public int injuryType;
    public String macAddress;


    public PatientInfo() {
        size = 8*4 + 17;
        request = 0;
        bodyWeight = 0;
        weightCorrection = 0;
        totalThreshold = 0;
        backThreshold = 0;
        frontThreshold = 0;
        injuryType = 0;
        macAddress = "";
    }

    public boolean getPatientInfo(File file) {
        try {
            int length = (int)file.length();
            byte[] data = new byte[length];
            FileInputStream input = new FileInputStream(file);
            input.read(data);

            ByteBuffer buf = ByteBuffer.allocate(length);
            buf.put(data);
            buf.position(0);

            if(size != buf.getInt())
            {
                input.close();
                return false;
            }
            request = buf.getInt();
            bodyWeight = buf.getInt();
            weightCorrection = buf.getInt();
            totalThreshold = buf.getInt();
            backThreshold = buf.getInt();
            frontThreshold = buf.getInt();
            injuryType = buf.getInt();
            byte[] macAddrBytes = new byte[17];
            buf.get(macAddrBytes);
            macAddress = new String(macAddrBytes);

            input.close();
            return true;
        } catch (Exception e) {
            request = 0;
            Log.i("Exception", e.getMessage());
        }
        return false;
    }
}