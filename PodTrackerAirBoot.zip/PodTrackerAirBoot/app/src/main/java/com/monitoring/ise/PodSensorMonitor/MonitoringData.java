package com.monitoring.ise.PodSensorMonitor;

import android.content.Context;
import android.util.Log;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Hashtable;

public class MonitoringData {

    public static final String patientDataFile = "MonitoringData.dat";
    static final String[] injuryString = {"None","Toe Touch","Heel","Partial","Full"};
    // generic data
    private int         backMaxMonitor;
    private int         frontMaxMonitor;
    private int         bodyWeight;
    private int         backPercent;
    private int         frontPercent;
    private String      alarmMsg;
    private int         alarmMax; // 0 - no Alarm; 1 - Back; 2 - Front 3 - Total
    private boolean     alarmON;
    private final int   batteryCriticalLevel;
    private int         batteryLevel;
    private int         injuryType;

    // Graph data
    private int startDay;
    private int startYear;
    private int lastIndex;
    private int firstDayIndex;
    private int curHour;

    private DataMonitorArray data24hrs;
    private DataMonitorArray data123days;
    public Calendar datetime;

    private SavedMonitoringData dataTotal;
    public MonitoringData(Context context) {
        backMaxMonitor = 0;
        frontMaxMonitor = 0;
        alarmMsg = "";
        alarmMax = 0;
        alarmON = false;
        batteryCriticalLevel = 10;
        batteryLevel = 0;
        startDay = 0;
        startYear = 0;
        curHour = 0;
        datetime = new GregorianCalendar();
        data24hrs = new DataMonitorArray(24);
        data123days = new DataMonitorArray((SavedMonitoringData.TotalDataDays / 7) * 8);
        restoreSavedMonitoringData(context);
    }
    private void restoreSavedMonitoringData(Context context) {
        try {
            //Read from the stored file
            FileInputStream file = context.openFileInput(patientDataFile);
            ObjectInputStream input = new ObjectInputStream(file);
            dataTotal = (SavedMonitoringData) input.readObject();
            //data24hrs.setData(dataTotal.data24hrs);
            //curHour = retrieveShort(dataTotal.data24hrs,96);
            set123daysArray(dataTotal.data123days);
            input.close();
            file.close();
        } catch (InvalidClassException e) {
            context.deleteFile(patientDataFile);
            dataTotal = new SavedMonitoringData();
        } catch (Exception e) {
            Log.i("Serialize Exception", "TotalMonitorArray: ");
            dataTotal = new SavedMonitoringData();
        }
    }
    public static Hashtable<Integer, Integer[]> injuryThresholdCoefTable =
            new Hashtable<Integer,Integer[]>();
    static {
        // Array of coefficients for                 [ Total, Back, Front ]
        injuryThresholdCoefTable.put(0,new Integer[] { 0,     5,    5,    });
        injuryThresholdCoefTable.put(1,new Integer[] { 0,     5,    15,   });
        injuryThresholdCoefTable.put(2,new Integer[] { 0,     100,  5,    });
        injuryThresholdCoefTable.put(3,new Integer[] { 50,    0,    0,    });
        injuryThresholdCoefTable.put(4,new Integer[] { 100,   0,    0,    });
    }
    public void updateThresholds() {
        dataTotal.totalThreshold =  (dataTotal.bodyWeight * injuryThresholdCoefTable.get(injuryType)[0]) / 100;
        dataTotal.backThreshold = (dataTotal.bodyWeight * injuryThresholdCoefTable.get(injuryType)[1]) / 100;
        dataTotal.frontThreshold = (dataTotal.bodyWeight * injuryThresholdCoefTable.get(injuryType)[2]) / 100;
    }
    int retrieveShort(byte[] data, int index)    {
        ByteBuffer bb = ByteBuffer.wrap(data);
        bb.order(ByteOrder.LITTLE_ENDIAN);
        return (int)bb.getShort(index);
    }
    public boolean storeTotalMonitoringData(Context context) {
        try {
            FileOutputStream file = context.openFileOutput(patientDataFile, Context.MODE_PRIVATE);
            ObjectOutputStream output = new ObjectOutputStream(file);
            output.writeObject(dataTotal);
            output.close();
            file.close();
            return  true;
        } catch (Exception e) {
            Log.i("Serialize Exception", "TotalMonitorArray: ");
            return false;
        }
    }
    public void resetMonitoringData() {
        data24hrs = new DataMonitorArray(24);
        data123days = new DataMonitorArray((SavedMonitoringData.TotalDataDays / 7) * 8);
        startDay = 0;
        startYear = 0;
        curHour = 0;
        dataTotal.clear24hrsData();
        dataTotal.clear123daysData();
    }
    public void set24hrsArray(byte[] data) {
        data24hrs.setData(data);
        curHour = retrieveShort(data,96);
        dataTotal.set24hrsData(data);
    }
    public void set123daysArray(byte[] data) {
        ByteBuffer bb = ByteBuffer.wrap(data);
        bb.order(ByteOrder.LITTLE_ENDIAN);

        bb.position(121 * 4);
        int index = (int)bb.getShort();
        startYear = (int)bb.getShort();
        startDay = (int)bb.getShort();
        injuryType = (int)bb.getShort();
        bodyWeight  = (int)bb.getShort();
        backPercent = (int)bb.get();
        frontPercent= (int)bb.get();
        dataTotal.set123daysData(data);
        // set weekly start index
        datetime.set(Calendar.YEAR, startYear);
        datetime.set(Calendar.DAY_OF_YEAR, startDay);
        firstDayIndex = datetime.get(Calendar.DAY_OF_WEEK) - 1;
        datetime.add(Calendar.DAY_OF_YEAR, - firstDayIndex);
        lastIndex = firstDayIndex + index;
        data123days.setData(data, firstDayIndex, index + 1);
    }
    public boolean setMonitorArrays(byte[] data) {
        ByteBuffer bb = ByteBuffer.wrap(data);
        bb.order(ByteOrder.LITTLE_ENDIAN);
        bb.position(1);
        batteryLevel = DataMonitorArray.convert(bb.get());
        backMaxMonitor = DataMonitorArray.convert(bb.get());
        frontMaxMonitor = DataMonitorArray.convert(bb.get());
        checkAlarms();
        int indx = DataMonitorArray.convert(bb.get());
        curHour = indx;
//        data24hrs.index = indx;
        data24hrs.steps[indx] = bb.getShort();
        data24hrs.alarms[indx] = bb.getShort();
        indx = DataMonitorArray.convert(bb.get());
        lastIndex = indx + firstDayIndex;
//        data123days.index = indx;
        data123days.steps[lastIndex] = bb.getShort();
        data123days.alarms[lastIndex] = bb.getShort();
        // return true if there is a request to adjust strap tension
        if(bb.get() == 1)
            return true;
        return false;
        // update graph data
    }
    public byte[] syncOpData() {
        final byte[] podData = new byte[20];
        ByteBuffer bb = ByteBuffer.wrap(podData);
        bb.order(ByteOrder.LITTLE_ENDIAN);
        bb.put((byte) 1);  //mode
        bb.put((byte) 0);  //weightAdjustment
        bb.put((byte) 0);  //backThreshold
        bb.put((byte) 0);  //frontThreshold
        bb.put((byte) 0);  //totalThreshold
        bb.put((byte) 0);  //frontPercent
        bb.put((byte) 0);  //backPercent
        bb.put((byte) 0);  //injuryType
        bb.put((byte) 0);  //bodyWeight
        Calendar datetime = new GregorianCalendar();
        datetime.setTimeInMillis(System.currentTimeMillis());
        bb.put((byte) datetime.get(Calendar.MINUTE));
        bb.put((byte) datetime.get(Calendar.SECOND));
        bb.put((byte) datetime.get(Calendar.HOUR_OF_DAY));
        bb.putShort((short) datetime.get(Calendar.MILLISECOND));
        bb.putShort((short) datetime.get(Calendar.DAY_OF_YEAR));
        bb.putShort((short) datetime.get(Calendar.YEAR));
        return podData;
    }
    public boolean isAlarmON() {
        return alarmON;
    }
    public void setAlarmON(boolean alarmON) {
        this.alarmON = alarmON;
    }
    public int getBatteryPercent() {
        return batteryLevel;
    }
    public byte[] setMonitorMode(boolean enable) {
        final byte[] res = new byte[20];
        if (enable)
            res[0] = 0x02;
        else
            res[0] = 0x03;
        return res;
    }
    public byte[] setAlarmSound(boolean enable) {
        final byte[] res = new byte[20];
        if (enable)
            res[0] = 0x04;
        else
            res[0] = 0x05;
        return res;
    }
    public int getBackMaxMonitor() {
        return backMaxMonitor;
    }
    public int getFrontMaxMonitor() {
        return frontMaxMonitor;
    }
    public int getBackPercent() {
        return backPercent;
    }
    public int getFrontPercent() {
        return frontPercent;
    }
    public String getAlarmMsg() {
        return alarmMsg;
    }
    public boolean setAlarms(Context context, int back, int front) {
        Calendar datetime = new GregorianCalendar();
        datetime.setTimeInMillis(System.currentTimeMillis());
        if(getBackPercent() < back && getFrontPercent() < front)
        {
            alarmMax = back + front ;
            alarmMsg = String.format("%1$s          %2$d%3$s %4$tl:%4$tM %4$tp", context.getString(R.string.notify_Totoal_Overloaded),alarmMax,"% at ",datetime);
            return true;
        }
        else if(getBackPercent() < back) {

            alarmMax = back;
            alarmMsg = String.format("%1$s          %2$d%3$s %4$tl:%4$tM %4$tp", context.getString(R.string.notify_Back_Overloaded), alarmMax, "% at ", datetime);
            return true;
        }
        else if(getFrontPercent() < front)
        {
            alarmMax = front;
            alarmMsg = String.format("%1$s           %2$d%3$s %4$tl:%4$tM %4$tp", context.getString(R.string.notify_Front_Overloaded), alarmMax, "% at ", datetime);
            return true;
        }

        return false;
    }
    public void checkAlarms() {
        boolean alarmOff = true;
        if(dataTotal.backThreshold > 0 )
            alarmOff = alarmOff && backMaxMonitor < dataTotal.backThreshold;
        if(dataTotal.frontThreshold > 0)
            alarmOff = alarmOff && frontMaxMonitor < dataTotal.frontThreshold;
        if(dataTotal.totalThreshold > 0)
            alarmOff = alarmOff && (backMaxMonitor + frontMaxMonitor) < dataTotal.totalThreshold;
        if(alarmOff) {
            alarmMax = 0;
            alarmON = false;
        }
    }
    public String getBatteryLevel() {
        if (batteryLevel <= batteryCriticalLevel)
            return String.format("%1$s%2$d%3$s", "Critical Battery Level: ", batteryLevel, "%");
        else
            return String.format("%1$s%2$d%3$s", "Battery Level: ", batteryLevel, "%");
    }
    public float[] get24hrsAlarms(boolean logarithmic) {
        if(logarithmic)
            return data24hrs.getAlarmsLog10();
        else
            return data24hrs.getAlarms();
    }
    public float[] get24hrsSteps(boolean logarithmic) {
        if(logarithmic)
            return data24hrs.getStepsLog10();
        else
            return data24hrs.getSteps();
    }
    public float[] get123daysAlarms(boolean logarithmic) {
        if(logarithmic)
            return data123days.getAlarmsLog10();
        else
            return data123days.getAlarms();
    }
    public float[] get123daysSteps(boolean logarithmic) {
        if(logarithmic)
            return data123days.getStepsLog10();
        else
            return data123days.getSteps();
    }

    public int getLastIndex() {
        return lastIndex;
    }
    public int getCurHour() {
        return curHour;
    }
    public Calendar getDateTime() {
        return datetime;
    }
    public int getTotalDayAlarms() {
        return data123days.alarms[lastIndex];
    }
    public int getTotalDaySteps() {
        return data123days.steps[lastIndex];
    }
    public int getWeeklyDayAlarms(int index) {
        int sum = 0;
        for(int i=0; i<7; i++)
            sum += data123days.alarms[index++];
        return sum;
    }
    public int getWeeklyDaySteps(int index) {
        int sum = 0;
        for(int i=0; i<7; i++)
            sum += data123days.steps[index++];
        return sum;
    }
    public String getDeviceAddress() {
        return dataTotal.deviceAddress;
    }
    public void setDeviceAddress(String deviceAddress) {
        dataTotal.deviceAddress = deviceAddress;
    }
    public int getBackThreshold() {
        return dataTotal.backThreshold;
    }
    public int getFrontThreshold() {
        return dataTotal.frontThreshold;
    }
    public int getTotalThreshold() {
        return dataTotal.totalThreshold;
    }
    public void setBackThreshold(int threshold) {
        dataTotal.backThreshold = threshold;
    }
    public void setFrontThreshold(int threshold) {
        dataTotal.frontThreshold = threshold;
    }
    public void setTotalThreshold(int num) {
        dataTotal.totalThreshold = num;
    }
    public int getBodyWeight() {
        return dataTotal.bodyWeight;
    }
    public void setBodyWeight(int weight) {
        dataTotal.bodyWeight = weight;
    }
    public void setBackAdjustment(int coef) {
        dataTotal.weightAdjustment = coef;
    }
    public void setInjuryType(int type) { dataTotal.injuryType = type; }
    public String getInjuryType() {
        return injuryString[injuryType];
    }
}
