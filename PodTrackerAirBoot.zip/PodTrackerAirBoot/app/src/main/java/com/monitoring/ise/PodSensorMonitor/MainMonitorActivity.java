package com.monitoring.ise.PodSensorMonitor;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.*;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.*;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.view.animation.Transformation;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class MainMonitorActivity extends AppCompatActivity {

    private static final long PULL_DATA_PERIOD = 600000;
    private static final long READ_WRITE_DELAY = 2000;
    private static final int PERMISSIONS_REQUESTS = 3;

    public static final int REQUEST_CALIBRATE_DATA = 40;
    public static final int RESPONSE_CALIBRATE_DATA = 41;

    private enum ShowGraph {show25min, show24hrs, showTotal}
    private static ShowGraph showGraph = ShowGraph.showTotal;
    public MonitoringData monitoringData;
    private boolean logScaleOn = false;
    private boolean permissionBle;
    private boolean permissionWrite;
    private SoleSensorBleService mSoleSensorBleService;
    private boolean serviceAvailable;
    //private boolean poolDataRequests;
    private boolean monitorMode;
    private boolean reconnectMode;
    private boolean showAlertDialog = true;
    private boolean notifyActive;
    private Handler mHandler;
    private byte[] opDataArray;

    private TextView mConnectionState;
    private TextView mBackMonitor;
    private TextView mFrontMonitor;
    private TextView mStepsToday;
    private TextView mStepsTotal;
    private TextView mAlarmsToday;
    private TextView mAlarmsTotal;
    private TextView frontAlarmsToday;
    private TextView frontAlarmsTotal;
    private TextView mOverloadMessage;
    private TextView mBatteryPercent;
    private ImageView mLeftNeedle;
    private ImageView mRightNeedle;
    private TimeBarGraph mTotalHrsGraph;
    private RadioGroup mRadioButtons;
    private WeightGauge leftWeightScale;
    private WeightGauge rightWeightScale;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_monitor);
        mConnectionState = findViewById(R.id.mConnectionState);
        mBackMonitor = findViewById(R.id.mBackPercent);
        mFrontMonitor = findViewById(R.id.mFrontPercent);
        mStepsToday = findViewById(R.id.mStepsToday);
        mAlarmsToday = findViewById(R.id.alarmsToday);
        mOverloadMessage = findViewById(R.id.mOverloadMessage);
        mBatteryPercent = findViewById(R.id.mBatteryPercent);
        mLeftNeedle = findViewById(R.id.leftNeedle);
        mRightNeedle = findViewById(R.id.rightNeedle);
        mTotalHrsGraph = findViewById(R.id.timeBarGraph);
        mRadioButtons = findViewById(R.id.radioGroup2);
        mHandler = new Handler();
        leftWeightScale = findViewById(R.id.weightGauge);
        rightWeightScale = findViewById(R.id.weightGauge2);

        mRadioButtons.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if(checkedId == R.id.radioButton3) {
                    showGraph = ShowGraph.show24hrs;
                    setDaylyGraph();
                    updateDaylyGraph();
                    updateTotalData(mStepsToday, monitoringData.getTotalDaySteps());
                    updateTotalData(mAlarmsToday, monitoringData.getTotalDayAlarms());

                }
                else if (checkedId == R.id.radioButton4){
                    showGraph = ShowGraph.showTotal;
                    setWeeklyGraph();
                    updateWeeklyGraph();
                    updateTotalData(mStepsToday, monitoringData.getWeeklyDaySteps(mTotalHrsGraph.weekIndex()));
                    updateTotalData(mAlarmsToday, monitoringData.getWeeklyDayAlarms(mTotalHrsGraph.weekIndex()));
                }
                else {
                    showGraph = ShowGraph.show24hrs;
                    setDaylyGraph();
                    updateDaylyGraph();
                    updateTotalData(mStepsToday, monitoringData.getTotalDaySteps());
                    updateTotalData(mAlarmsToday, monitoringData.getTotalDayAlarms());
                }

            }
        });
        serviceAvailable = false;
        //poolDataRequests = false;
        notifyActive = false;
        monitorMode = false;
        reconnectMode = false;

        permissionBle = true;
        permissionWrite = true;
        final List<String> permissionsList = new ArrayList<String>();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            permissionsList.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
            permissionWrite = false;
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            permissionsList.add(Manifest.permission.READ_EXTERNAL_STORAGE);
            permissionWrite = false;
        }
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            permissionsList.add(Manifest.permission.ACCESS_FINE_LOCATION);
            permissionBle = false;
        }
        if (permissionsList.size() > 0) {
            // No explanation needed; request the permission
            ActivityCompat.requestPermissions(this,
                    permissionsList.toArray(new String[permissionsList.size()]),
                    PERMISSIONS_REQUESTS);
        }
        else if(!initConnection()) {
            AlertDialog alertDialog = new AlertDialog.Builder(this).create();
            alertDialog.setTitle("Terminated");
            alertDialog.setMessage("Please download PODProfile.dat file or run PodSensorMgmt App");
            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                            android.os.Process.killProcess(android.os.Process.myPid());
                            System.exit(1);
                        }
                    });
            alertDialog.show();
        }

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.options_menu,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        String n= item.getTitle().toString();
        switch (n) {
            case "Mute Alarm":
                if(serviceAvailable) {
                    item.setTitle(R.string.action_settings_on);
                    mSoleSensorBleService.soundAlarmOnOff(false);
                    opDataArray = monitoringData.setAlarmSound(true);
                    mSoleSensorBleService.dataOpMode.setValue(opDataArray);
                    mSoleSensorBleService.writeCharacteristic(mSoleSensorBleService.dataOpMode);
                }
                break;
            case "Sound Alarm":
                if(serviceAvailable) {
                    item.setTitle(R.string.action_settings_off);
                    mSoleSensorBleService.soundAlarmOnOff(true);
                    opDataArray = monitoringData.setAlarmSound(false);
                    mSoleSensorBleService.dataOpMode.setValue(opDataArray);
                    mSoleSensorBleService.writeCharacteristic(mSoleSensorBleService.dataOpMode);
                }
                break;
//            case "Tighten straps":
//                if(serviceAvailable) {
//                    final byte[] res = new byte[20];
//                    Arrays.fill(res, (byte) 0);
//                    res[0] = (byte)8;
//                    mSoleSensorBleService.dataOpMode.setValue(res);
//                    mSoleSensorBleService.writeCharacteristic(mSoleSensorBleService.dataOpMode);
//                }
//                break;
        }
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    public void onClickButtonAdjustStraps(View view) {
        if(serviceAvailable) {
            final byte[] res = new byte[20];
            Arrays.fill(res, (byte) 0);
            res[0] = (byte)8;
            mSoleSensorBleService.dataOpMode.setValue(res);
            mSoleSensorBleService.writeCharacteristic(mSoleSensorBleService.dataOpMode);
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        if (requestCode == PERMISSIONS_REQUESTS) {
            for (int i = 0; i < grantResults.length; i++) {
                if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                    if (Manifest.permission.WRITE_EXTERNAL_STORAGE.equals(permissions[i]))
                        permissionWrite = true;
                    if (Manifest.permission.ACCESS_FINE_LOCATION.equals(permissions[i]))
                        permissionBle = true;
                }
            }
        }
        if(!(permissionBle && permissionWrite)) {
            AlertDialog alertDialog = new AlertDialog.Builder(this).create();
            alertDialog.setTitle("Terminated");
            alertDialog.setMessage("Please Allow the Access to enable POD interaction");
            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                            android.os.Process.killProcess(android.os.Process.myPid());
                            System.exit(1);
                        }
                    });
            alertDialog.show();
        } else if(!initConnection()) {
            AlertDialog alertDialog = new AlertDialog.Builder(this).create();
            alertDialog.setTitle("Terminated");
            alertDialog.setMessage("Please download PODProfile.dat file or run PodSensorSetup App");
            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                            android.os.Process.killProcess(android.os.Process.myPid());
                            System.exit(1);
                        }
                    });
            alertDialog.show();
        }
    }
    private boolean checkPatientInfo() {
        boolean status = false;
        File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        File file = new File(dir, PatientInfo.patientFileName);
        if (file.exists()) {
            //Read from the file
            PatientInfo patientInfo = new PatientInfo();
            if (patientInfo.getPatientInfo(file)) {
                monitoringData.setDeviceAddress(patientInfo.macAddress);
                monitoringData.setTotalThreshold(patientInfo.totalThreshold);
                monitoringData.setBackThreshold(patientInfo.backThreshold);
                monitoringData.setFrontThreshold(patientInfo.frontThreshold);
                monitoringData.setBodyWeight(patientInfo.bodyWeight);
                monitoringData.setBackAdjustment(patientInfo.weightCorrection);
                monitoringData.setInjuryType(patientInfo.injuryType);
                // if data initialization requested
                if(patientInfo.request == 2) {
                    monitoringData.resetMonitoringData();
                }
                if(!monitoringData.getDeviceAddress().isEmpty()) {
                    monitoringData.storeTotalMonitoringData(getApplicationContext());
                    status = true;
                }
            }
//            file.delete();
        }
        return status;
    }
    private void getPatientData() {
        if (monitoringData == null) {
            monitoringData = new MonitoringData(getApplicationContext());
        }
    }
    private void setGaugeMargins() {
        float alarmMargin;
        if (monitoringData.getBackThreshold() == 0 && monitoringData.getFrontThreshold() == 0) {
            alarmMargin = (float) (monitoringData.getTotalThreshold() * 0.5f / (monitoringData.getBodyWeight() * 1.f));
            leftWeightScale.setAlarmMargin(alarmMargin);
            rightWeightScale.setAlarmMargin(alarmMargin);
        } else {
            alarmMargin = (float) (monitoringData.getBackThreshold() * 1.f / (monitoringData.getBodyWeight() * 1.f));
            leftWeightScale.setAlarmMargin(alarmMargin);
            alarmMargin = (float) (monitoringData.getFrontThreshold() * 1f / (monitoringData.getBodyWeight() * 1f));
            rightWeightScale.setAlarmMargin(alarmMargin);
        }
    }
    private boolean  initConnection() {
        getPatientData();
        checkPatientInfo();
        if (monitoringData.getDeviceAddress().isEmpty())
            return false;
        setGaugeMargins();
        return true;
    }
    private void suspendConnection() {
        if(reconnectMode) {
            mHandler.removeCallbacks(reconnect);
            reconnectMode = false;
        }
        if(monitoringData != null) {
            monitoringData.storeTotalMonitoringData(getApplicationContext());
        }
        if(monitorMode) {
            opDataArray = monitoringData.setMonitorMode(false);
            mSoleSensorBleService.dataOpMode.setValue(opDataArray);
            mSoleSensorBleService.writeCharacteristic(mSoleSensorBleService.dataOpMode);
        }
    }
    @Override
    protected void onResume() {
        super.onResume();
        if(permissionBle && permissionWrite && !monitoringData.getDeviceAddress().isEmpty()) {
            if (mSoleSensorBleService == null) {
                Intent gattServiceIntent = new Intent(this, SoleSensorBleService.class);
                bindService(gattServiceIntent, serviceConnection, BIND_AUTO_CREATE);
                registerReceiver(mGattUpdateReceiver, makeGattUpdateIntentFilter());
            } else if (!serviceAvailable) {
                mHandler.postDelayed(reconnect, READ_WRITE_DELAY);
                reconnectMode = true;
            } else /*if (!poolDataRequests)*/ {
                mHandler.postDelayed(syncOpDataTime, READ_WRITE_DELAY);
                //mHandler.postDelayed(read24hrsData, READ_WRITE_DELAY);
            }
        }
        //mRadioButtons.check(R.id.radioButton);
    }
    @Override
    protected void onPause() {
        super.onPause();
        suspendConnection();
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        monitoringData.storeTotalMonitoringData(getApplicationContext());
        unbindService(serviceConnection);
    }
    private final ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder service) {
            mSoleSensorBleService = ((SoleSensorBleService.LocalBinder) service).getService();
            if (!mSoleSensorBleService.initialize()) {
                finish();
            }
            // Automatically connects to the device upon successful start-up initialization.
            if(mSoleSensorBleService.connect(monitoringData.getDeviceAddress()))
                updatePodStatus(false, R.string.hint_Connecting);
        }
        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            mSoleSensorBleService = null;
        }
    };
    private final BroadcastReceiver mGattUpdateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
                 if (SoleSensorBleService.ACTION_GATT_CONNECTED   .equals(action)) {
                updatePodStatus(false, R.string.status_Connected_to_POD);
                mHandler.removeCallbacks(reconnect);
                reconnectMode = false;
            }
            else if (SoleSensorBleService.ACTION_GATT_DISCONNECTED.equals(action)) {
                updatePodStatus(false, R.string.status_POD_Disconnected);
                updateMessage(mBatteryPercent, "");
                serviceAvailable = false;
                monitorMode = false;
                mHandler.postDelayed(reconnect, READ_WRITE_DELAY);
                reconnectMode = true;
            }
            else if (SoleSensorBleService.ACTION_GATT_DISCOVERED  .equals(action)) {
                updatePodStatus(false,R.string.status_Discover_POD_Service);
                serviceAvailable = true;
                mHandler.postDelayed(syncOpDataTime, READ_WRITE_DELAY);
            }
            else if (SoleSensorBleService.ACTION_WRITE_COMPLETE   .equals(action)) {
                byte mode = intent.getByteExtra(SoleSensorBleService.DATA_OPMODE, (byte)10);
                if(mode == 0 || mode == 1) {
                    SystemClock.sleep(1000);
                    mSoleSensorBleService.readCharacteristic(mSoleSensorBleService.data24hrs);
                    updatePodStatus(true, R.string.status_Receiving_Data);
                }
                else if(mode == 2) {
                    monitorMode = true;
                    updatePodStatus(false, R.string.status_Connected_to_POD);
                }
                else if(mode == 3) {
                    monitorMode = false;
                   // poolDataRequests = true;
                }
                else if (mode == 8) {
                    Intent nextIntent = new Intent(getApplicationContext(), BootStrapsActivity.class);
                    startActivityForResult(nextIntent,REQUEST_CALIBRATE_DATA);
                }
            }
            else if (SoleSensorBleService.NOTIFY_DATA_AVAILABLE   .equals(action)) {
                byte[] ar = intent.getByteArrayExtra(SoleSensorBleService.DATA_MONITOR_NOTIFY);
                if (ar != null && ar.length == 20) {
                   if (ar[0] == 0x44) {
                        // Monitor Data returns true if there is a request to adjust strap tension
                        if(monitoringData.setMonitorArrays(ar)) {
                            final byte[] res = new byte[20];
                            Arrays.fill(res, (byte) 0);
                            res[0] = (byte)8;
                            mSoleSensorBleService.dataOpMode.setValue(res);
                            mSoleSensorBleService.writeCharacteristic(mSoleSensorBleService.dataOpMode);
                        }
                        else {
                            // update battery status
                            if (monitoringData.getBatteryPercent() == 5) {
                                updatePodStatus(true, R.string.status_Charge_POD_Battery);
                            }
                            // update text data
                            updateMessage(mBatteryPercent, monitoringData.getBatteryLevel());
                            updatePodData(mBackMonitor, monitoringData.getBackMaxMonitor());
                            updatePodData(mFrontMonitor, monitoringData.getFrontMaxMonitor());
                            // update Gauge indicator
                            updateMonitorGauge(monitoringData.getBackMaxMonitor(), monitoringData.getFrontMaxMonitor());
                            // update Bar Graph
                            if (showGraph == ShowGraph.show24hrs) {
                                updateTotalData(mStepsToday, monitoringData.getTotalDaySteps());
                                updateTotalData(mAlarmsToday, monitoringData.getTotalDayAlarms());
                            } else {
                                updateTotalData(mStepsToday, monitoringData.getWeeklyDaySteps(mTotalHrsGraph.weekIndex()));
                                updateTotalData(mAlarmsToday, monitoringData.getWeeklyDayAlarms(mTotalHrsGraph.weekIndex()));
                            }
                            updateGraph();
                        }
                   }
                   else if (ar[0] == 0x41) {
                       //Alarm Data
                        monitoringData.setAlarmON(true);
                        final int mBack = ar[1] < 0 ? 256 + ar[1] : ar[1];
                        final int mFront = ar[2] < 0 ? 256 + ar[2] : ar[2];
                        if(monitoringData.setAlarms(getApplicationContext(), mBack, mFront)) {
                            updateMessage(mOverloadMessage, monitoringData.getAlarmMsg());
                        }
                        if(notifyActive) {
                            mHandler.removeCallbacks(hideNotify);
                            mHandler.postDelayed(hideNotify, 300000);
                        } else {
                            notifyActive = true;
                            mHandler.postDelayed(hideNotify, 300000);
                        }
                    }
                }
            }
            else if (SoleSensorBleService.DATA_24HRS_AVAILABLE    .equals(action)) {
                byte[] ar = intent.getByteArrayExtra(SoleSensorBleService.DATA_ARRAY_24HRS);
                if (ar != null && ar.length == 98) {
                    monitoringData.set24hrsArray(ar);
                    mSoleSensorBleService.readCharacteristic(mSoleSensorBleService.data127hrs);
                }
            }
            else if (SoleSensorBleService.DATA_127HRS_AVAILABLE   .equals(action)) {
                byte[] ar = intent.getByteArrayExtra(SoleSensorBleService.DATA_ARRAY_127HRS);
                if (ar != null && ar.length == (SavedMonitoringData.TotalDataDays * 4 + 12)) {
                    monitoringData.set123daysArray(ar);
                    setGaugeMargins();
                    monitoringData.storeTotalMonitoringData(getApplicationContext());
                    updateTotalData(mStepsToday, monitoringData.getTotalDaySteps());
                    updateTotalData(mAlarmsToday, monitoringData.getTotalDayAlarms());
                    showGraph = ShowGraph.showTotal;
                    setWeeklyGraph();
                    updateGraph();
                    if(!monitorMode) {
                        opDataArray = monitoringData.setMonitorMode(true);
                        mSoleSensorBleService.dataOpMode.setValue(opDataArray);
                        mSoleSensorBleService.writeCharacteristic(mSoleSensorBleService.dataOpMode);
                    }
                }
            }
            else if (TimeBarGraph.ACTION_CHANGE_GRAPH.equals(action)){
                updateTotalData(mStepsToday, monitoringData.getWeeklyDaySteps(mTotalHrsGraph.weekIndex()));
                updateTotalData(mAlarmsToday, monitoringData.getWeeklyDayAlarms(mTotalHrsGraph.weekIndex()));
            }
        }
    };
    private static IntentFilter makeGattUpdateIntentFilter() {
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(SoleSensorBleService.ACTION_GATT_CONNECTED);
        intentFilter.addAction(SoleSensorBleService.ACTION_GATT_DISCONNECTED);
        intentFilter.addAction(SoleSensorBleService.ACTION_GATT_DISCOVERED);
        intentFilter.addAction(SoleSensorBleService.NOTIFY_DATA_AVAILABLE);
        intentFilter.addAction(SoleSensorBleService.DATA_24HRS_AVAILABLE);
        intentFilter.addAction(SoleSensorBleService.DATA_127HRS_AVAILABLE);
        intentFilter.addAction(SoleSensorBleService.ACTION_WRITE_COMPLETE);
        intentFilter.addAction(TimeBarGraph.ACTION_CHANGE_GRAPH);
        return intentFilter;
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        //     connectToPod.setEnabled(true);
        if (requestCode == REQUEST_CALIBRATE_DATA && resultCode == RESPONSE_CALIBRATE_DATA) {
            opDataArray = monitoringData.setMonitorMode(true);
            mSoleSensorBleService.dataOpMode.setValue(opDataArray);
            mSoleSensorBleService.writeCharacteristic(mSoleSensorBleService.dataOpMode);
        }
    }
    private void updatePodStatus(final boolean attn , final int resourceId) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if(attn)
                    mConnectionState.setTextColor(Color.RED);
                else
                    mConnectionState.setTextColor(Color.BLACK);
                mConnectionState.setText(resourceId);
            }
        });
    }
    private void updatePodData(final TextView view, final int data) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                String str = Integer.toString(data) + "%";
                view.setText(str);
            }
        });
    }
    private void updateTotalData(final TextView view, final int data) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                view.setText(Integer.toString(data));
            }
        });
    }
    private void updateMessage(final TextView view, final String msg) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                view.setText(msg);
            }
        });
    }
    private void updateMonitorGauge(final int heelWeight, final int frontWeight) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                setMonitorGauge(mLeftNeedle, 0, heelWeight);
                setMonitorGauge(mRightNeedle, 1, frontWeight);
            }
        });
    }
    private void updateDaylyGraph() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mTotalHrsGraph.updateGraph(monitoringData.get24hrsSteps(logScaleOn), monitoringData.get24hrsAlarms(logScaleOn), monitoringData.getCurHour());
            }
        });
    }
    private void updateWeeklyGraph() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                //monitoringData.setWeekArrays( displayWeekNo );
                mTotalHrsGraph.updateGraph(monitoringData.get123daysSteps(false), monitoringData.get123daysAlarms(false), monitoringData.getLastIndex());
            }
        });
    }
    private float previousLeftAngle = 0f;
    private float previousRightAngle = 0f;
    public void setMonitorGauge(ImageView mNeedle, final int position, int data) {
        final float currentAngle;
        final float pivotX;
        final float pivotY;
        final float prevAngle;
        if(position == 0) {
            pivotX = mNeedle.getWidth() - 15f;
            prevAngle = previousLeftAngle;
            currentAngle = (data * 0.9F > 90f)?90f:data * 0.9F;
        } else {
            prevAngle = previousRightAngle;
            currentAngle = (- data * 0.9f < -90f)? -90f:- data * 0.9f;
            pivotX = 15f;
        }
        pivotY = mNeedle.getHeight()/2f;
        RotateAnimation needleDeflection=new RotateAnimation(prevAngle, currentAngle, pivotX, pivotY) {
            protected void applyTransformation(float interpolatedTime, Transformation t) {
                float degrees;
                if(position == 0) {
                    degrees = prevAngle + (currentAngle - prevAngle) * interpolatedTime;
                } else {
                    degrees = prevAngle - (currentAngle - prevAngle) * interpolatedTime;
                }
                t.getMatrix().setRotate(degrees, pivotX, pivotY);
                super.applyTransformation(interpolatedTime, t);
            }

        };
        needleDeflection.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation arg0) {}
            @Override
            public void onAnimationRepeat(Animation arg0) {}
            @Override
            public void onAnimationEnd(Animation arg0) {
                if (position == 0) {
                    previousLeftAngle = currentAngle;
                } else {
                    previousRightAngle = currentAngle;
                }
            }
        });
        needleDeflection.setDuration(200);
        needleDeflection.setFillAfter(true);
        mNeedle.startAnimation(needleDeflection);
        mNeedle.refreshDrawableState();
    }
    public void onAlarmMsgClick(View view) {
        if(!monitoringData.isAlarmON()) {
            mOverloadMessage.setText("");
            if(notifyActive) {
                notifyActive = false;
                mHandler.removeCallbacks(hideNotify);
            }
        }
    }
    private Runnable syncOpDataTime = new Runnable() {
        @Override
        public void run() {
            if( mSoleSensorBleService.dataOpMode.setValue(monitoringData.syncOpData()))
                mSoleSensorBleService.writeCharacteristic(mSoleSensorBleService.dataOpMode);
        }
    };
    private Runnable reconnect = new Runnable() {
        @Override
        public void run() {
            mSoleSensorBleService.connect(monitoringData.getDeviceAddress());
            mHandler.postDelayed(reconnect, READ_WRITE_DELAY);
        }
    };
    private Runnable read24hrsData = new Runnable() {
        @Override
        public void run() {
            mSoleSensorBleService.readCharacteristic(mSoleSensorBleService.data24hrs);
            //poolDataRequests = true;
            updatePodStatus(true, R.string.status_Receiving_Data);
            mHandler.postDelayed(read24hrsData, PULL_DATA_PERIOD);
        }
    };
    private Runnable hideNotify = new Runnable() {
        @Override
        public void run() {
            updateMessage(mOverloadMessage, "");
            notifyActive = false;
        }
    };
    private void updateGraph() {
        switch(showGraph) {
            case show25min:
            case show24hrs:
                updateDaylyGraph();
                break;
            case showTotal:
                updateWeeklyGraph();
                break;
        }

    }
    private void setDaylyGraph() {
        if(logScaleOn) {
//            mTotalHrsGraph.setLimits((float) Math.log10(1000),500, 24, 24);
//            float[] yValues = {(float) Math.log10(5), (float) Math.log10(10), (float) Math.log10(100), (float) Math.log10(500)};
//            mTotalHrsGraph.setYMajorValues(yValues);
//            mTotalHrsGraph.setYMajorStrings(new String[] {"5","10","100","1000"});
        }
        else {
            mTotalHrsGraph.setLimits(1000, 8, 500,monitoringData.getCurHour(), null, monitoringData.getInjuryType());
            float[] yValues = {200,400,600, 800};
            mTotalHrsGraph.setYMajorValues(yValues);
            mTotalHrsGraph.setYMajorStrings(new String[] {"200","400","600","800"});
        }
        mTotalHrsGraph.setXMajorStrings(new String[] {"12am","1am","2am", "3am", "4am", "5am","6am", "7am",
                                                      "8am","9am","10am","11am","12pm","1pm","2pm", "3pm",
                                                      "4pm","5pm","6pm", "7pm", "8pm", "9pm","10pm","11pm"});
    }
    private void setWeeklyGraph() {
        if(logScaleOn) {
//            mTotalHrsGraph.setLimits((float) Math.log10(5000), monitoringData.getLastIndex(), 122, 7);
//            float[] yValues = {(float) Math.log10(5f), (float) Math.log10(10f), (float) Math.log10(100f), (float) Math.log10(1000f), (float) Math.log10(3000f)};
//            mTotalHrsGraph.setYMajorValues(yValues);
//            mTotalHrsGraph.setYMajorStrings(new String[] {"5","10","100","1000","3000"});
        }
        else {
            mTotalHrsGraph.setLimits(5000, 7, 2500, monitoringData.getLastIndex(), monitoringData.getDateTime(), monitoringData.getInjuryType());
            float[] yValues = {1000f, 2000f, 3000f,4000f};
            mTotalHrsGraph.setYMajorValues(yValues);
            mTotalHrsGraph.setYMajorStrings(new String[] {"1000","2000","3000","4000"});
        }
        mTotalHrsGraph.setXMajorStrings(new String[] {"S","M","T","W","T","F","S"});
    }
}
