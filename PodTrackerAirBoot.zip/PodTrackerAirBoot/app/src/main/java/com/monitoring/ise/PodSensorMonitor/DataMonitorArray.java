package com.monitoring.ise.PodSensorMonitor;

import java.io.Serializable;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;

public class DataMonitorArray implements Serializable {
    private int size;
//    public int index;
    public int[] steps;
    public int[] alarms;

    public static int   convert(byte data) {
        return data < 0 ? 256 + data : data;
    }
    public static float getLog(int data) {
        if (data > 0) {
            if (data == 1)
                return (float) (Math.log10(2) / 2);
            else
                return (float) Math.log10(data);
        }
        return 0F;
    }

    public DataMonitorArray(int size) {
        this.size = size;
//        index = 0;
        alarms = new int[size];
        steps = new int[size];
        Arrays.fill(alarms, 0);
        Arrays.fill(steps, 0);
    }
    public void setData(byte[] data) {
        ByteBuffer bb = ByteBuffer.wrap(data);
        bb.order(ByteOrder.LITTLE_ENDIAN);
        int j = 0;
        for (int i = 0; i < size; i++) {
            steps[i] = bb.getShort(j);  j+= 2;
            alarms[i] = bb.getShort(j); j += 2;
        }
//        index = bb.getShort(j);
    }
    public void setData(byte[] data, int firstIndex, int length) {
        ByteBuffer bb = ByteBuffer.wrap(data);
        bb.order(ByteOrder.LITTLE_ENDIAN);
        int j = 0;
        for (int i = firstIndex; i < (firstIndex + length); i++) {
            steps[i] = bb.getShort(j);  j+= 2;
            alarms[i] = bb.getShort(j); j += 2;
        }
//        index = length;
    }
    public float[] getAlarmsLog10() {
        float[] data = new float[size];
        for (int i = 0; i < size; i++) {
            data[i] = getLog(alarms[i]);
        }
        return data;
    }
    public float[] getStepsLog10() {
        float[] data = new float[size];
        for (int i = 0; i < size; i++) {
            data[i] = getLog(steps[i]);
        }
        return data;
    }
    public float[] getAlarms() {
        float[] data = new float[size];
        for (int i = 0; i < size; i++)
            data[i] = (float) alarms[i];
        return data;
    }
    public float[] getSteps() {
        float[] data = new float[size];
        for (int i = 0; i < size; i++)
            data[i] = (float)steps[i];
        return data;
    }
    public int getTotalSteps() {
        int sum = 0;
        for (int data : steps)
            sum += data;
        return sum;
    }
    public int getTotalAlarms() {
        int sum = 0;
        for (int data : alarms)
            sum += data;
        return sum;
    }
 }
