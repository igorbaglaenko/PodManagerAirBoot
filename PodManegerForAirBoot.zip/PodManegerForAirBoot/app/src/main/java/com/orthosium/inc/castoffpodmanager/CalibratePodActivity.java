package com.orthosium.inc.castoffpodmanager;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;

public class CalibratePodActivity extends AppCompatActivity {

    short backWeight;
    short frontWeight;

    short thresholdFrontWeight;
    short thresholdBackWeight;
    short sittingFrontWeight;
    short sittingBackWeight;
    short sittingFrontWeightLevel;
    short sittingBackWeightLevel;

    byte[] podData = new byte[20];

    short[] recBackWeight = new short[128];
    short[] recFrontWeight = new short[128];
    int recIndex = 0;
    int recTotal = 0;

    short[] patientData;
    private TextView viewTitle;
    private TextView viewPromptMessage;
    private TextView viewPromptAction;
    private EditText dataSittingWeight;
    private Button buttonAction;

    private boolean stopRequest = false;
    private int measureArraySize = 4;
    private enum CalibrateState {IDLE, CALIBRATE_SITTING, CALIBRATE_FRONT, CALIBRATE_BACK,STOP_TEST}
    CalibrateState currentState = CalibrateState.IDLE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calibrate_pod);

        Bundle extraData = getIntent().getExtras();
        patientData = extraData.getShortArray(MainActivity.INTENT_CLIBRATE_POD_ACTIVITY);

        viewTitle = findViewById(R.id.view_title);
        viewPromptMessage = findViewById(R.id.viewPromptMessage);
        buttonAction = findViewById(R.id.buttonAction);
        dataSittingWeight = findViewById(R.id.data_sitting_weight);
        viewPromptAction = findViewById(R.id.viewPromptAction);
        buttonAction.setText("Save");
        //buttonAction.setEnabled(false);

        Arrays.fill(podData, (byte) 0);
        thresholdFrontWeight = 0;
        thresholdBackWeight = 0;
        viewTitle.setText("Sitting Weight Calibration");
        //viewPromptMessage.setText("Ensure all straps are tightened on the boot\n\nKeep boot in the air");
        viewPromptMessage.setText("Ensure all straps are tightened on the boot\n\nPlace the foot on the scale\nAsk patient to relax and do not apply additional weight");

        viewPromptAction.setText ("Enter readings from scale\nPress SAVE when ready");
        currentState = CalibrateState.CALIBRATE_SITTING;

        registerReceiver(mBleServiceReceiver, makeGattUpdateIntentFilter());
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(mBleServiceReceiver != null)
            unregisterReceiver(mBleServiceReceiver);
    }
    private void exitActivity() {
        unregisterReceiver(mBleServiceReceiver);
        mBleServiceReceiver = null;
        if(patientData[1] < 100 && thresholdFrontWeight >= 0 && thresholdFrontWeight < sittingFrontWeight)
            thresholdFrontWeight = (short)(sittingFrontWeight);
        if(patientData[0] < 100 && thresholdBackWeight >= 0 && thresholdBackWeight < sittingBackWeight)
            thresholdBackWeight = (short)(sittingBackWeight);

        podData[0] = (byte) 10;
        podData[1] = (byte) sittingBackWeight;
        podData[2] = (byte) thresholdBackWeight;
        podData[3] = (byte) sittingFrontWeight;
        podData[4] = (byte) thresholdFrontWeight;
        podData[5] = (byte) patientData[1];
        podData[6] = (byte) patientData[0];
        Intent returnIntent = new Intent();
        returnIntent.putExtra(MainActivity.INTENT_RESPONSE_CALIBRATE_DATA, podData);
        setResult(MainActivity.RESPONSE_CALIBRATE_DATA, returnIntent);
        finish();
    }
    // START: Receiving POD data
    private static IntentFilter makeGattUpdateIntentFilter() {
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(PodBleService.CALIBRATE_DATA_NOTIFY);

        return intentFilter;
    }
    private BroadcastReceiver mBleServiceReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            if (PodBleService.CALIBRATE_DATA_NOTIFY.equals(action)) {
                byte[] ar = intent.getByteArrayExtra(PodBleService.CALIBRATE_DATA_AVAILABLE);
                if (ar[0] == 0x43) {
                    if(!stopRequest) {
                        ByteBuffer bb = ByteBuffer.wrap(ar);
                        bb.order(ByteOrder.LITTLE_ENDIAN);
                        bb.position(7);
                        // Update parameters view
                        backWeight = bb.getShort();
                        frontWeight = bb.getShort();
                        // Collect calibration Data
                        recBackWeight[recIndex] = backWeight;
                        recFrontWeight[recIndex] = frontWeight;
                        recIndex = (recIndex + 1) % measureArraySize;
                        recTotal++;
                    }
                    else {
                        if(currentState == CalibrateState.CALIBRATE_SITTING) {
                            String str = dataSittingWeight.getText().toString();
                            if(str.isEmpty()) {
                                stopRequest = false;
                                showToast("Please enter readings from the scale");
                            }
                            else {
                                estimateSittingWeight(Integer.valueOf(str));
                                dataSittingWeight.setVisibility(View.INVISIBLE);
                                viewPromptAction.setText ("Press SAVE when ready");
                                if (patientData[1] > 0 ) {
                                    viewTitle.setText("Front Weight Calibration");
                                    if(patientData[1] < 100)
                                        updateMessage(String.format("Apply %slb to the BOOT FRONT", ((patientData[2] * patientData[1]) / 100) + sittingFrontWeightLevel));
                                    else
                                        updateMessage("Apply full weight to the BOOT FRONT");
                                    currentState = CalibrateState.CALIBRATE_FRONT;
                                    stopRequest = false;
                                } else if (patientData[0] > 0) {
                                    viewTitle.setText("Back Weight Calibration");
                                    if(patientData[0] < 100)
                                        updateMessage(String.format("Apply %slb to the BOOT BACK", ((patientData[2] * patientData[0]) / 100) + sittingBackWeightLevel));
                                    else
                                        updateMessage("Apply full weight to the BOOT BACK");
                                    currentState = CalibrateState.CALIBRATE_BACK;
                                    stopRequest = false;
                                } else
                                    exitActivity();
                            }
                        }
                        else if (currentState == CalibrateState.CALIBRATE_FRONT  ) {
                            estimateFrontWeight();
                            viewTitle.setText("Back Weight Calibration");
                            if(patientData[0] > 0 && patientData[0] < 100) {
                                updateMessage(String.format("Apply %slb to back of boot", (patientData[2] * patientData[0]) / 100) + sittingBackWeightLevel);
                                currentState = CalibrateState.CALIBRATE_BACK;
                                stopRequest = false;
                            }
                            else
                                exitActivity();
                        }
                        else if (currentState == CalibrateState.CALIBRATE_BACK   ){
                            estimateBackWeight();
                            currentState = CalibrateState.STOP_TEST;
                            exitActivity();
                        }

                    }
                }

            }
        }

    };
    private void updateMessage(final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                viewPromptMessage.setText(message);
           }
        });
    }
    private void showToast(final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();;;
            }
        });
    }
/*================================================================================================*/
// START: Data calculation
    private short averageWeight(short[] data) {
        short weight = 0;
        for (int i = 0; i < measureArraySize; i++) {
            weight += data[i];
        }
        weight = (short) (weight / measureArraySize);
        return weight;
    }
    private short maxWeight(short[] data) {
        short weight = 0;
        for (int i = 0; i < measureArraySize; i++) {
            if(weight < data[i])
                weight = data[i];
        }

        weight = (short) (weight +3);
        return weight;
    }
    private void estimateSittingWeight(Integer weightLevel) {
        sittingFrontWeight = maxWeight(recFrontWeight);
        sittingBackWeight = maxWeight(recBackWeight);
        sittingFrontWeightLevel = (short)((weightLevel * sittingFrontWeight)/(sittingFrontWeight + sittingBackWeight));
        sittingBackWeightLevel = (short)((weightLevel * sittingBackWeight)/(sittingFrontWeight + sittingBackWeight));
        recTotal = 0;
        recIndex = 0;
    }
    private void estimateFrontWeight() {
        thresholdFrontWeight = averageWeight(recFrontWeight);
        recTotal = 0;
        recIndex = 0;
    }
    private void estimateBackWeight() {
        thresholdBackWeight = averageWeight(recBackWeight);
    }
/* switch states */
     public void onClickButtonAction(View view) {
         String msg;
         if(recTotal < 10)
             showToast("Please hold your weight steady");
             //viewPromptMessage.setText("Please hold your weight steady");
         else
             stopRequest = true;
    }
}

