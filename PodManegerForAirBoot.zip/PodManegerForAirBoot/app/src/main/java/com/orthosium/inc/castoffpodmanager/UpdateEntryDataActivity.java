package com.orthosium.inc.castoffpodmanager;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class UpdateEntryDataActivity extends AppCompatActivity {

    private TextView bodyWeight;
    private TextView injuryType;
    private EditText frontPercent;
    private EditText backPercent;
    short[] patientData;
    private short mBodyWeight;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_entry_data);

        Bundle extraData = getIntent().getExtras();
        patientData = extraData.getShortArray(MainActivity.INTENT_UPDATE_ENTRY_ACTIVITY);

        mBodyWeight   = patientData[2];

        bodyWeight   = findViewById(R.id.data_bodyWeight);
        injuryType   = findViewById(R.id.data_injuryType);
        frontPercent = findViewById(R.id.data_frontPercent2);
        backPercent  = findViewById(R.id.data_backPercent2);

        bodyWeight.setText(String.valueOf(patientData[2]));
        injuryType.setText(PatientData.getInjuryType((int)patientData[3]));
        frontPercent.setText(String.valueOf(patientData[1]));
        backPercent.setText(String.valueOf(patientData[0]));

    }

    public void onButtonClick(View view) {
        patientData[1] = Short.valueOf(frontPercent.getText().toString());
        patientData[0] = Short.valueOf(backPercent.getText().toString());

        Intent returnIntent = new Intent();
        returnIntent.putExtra(MainActivity.INTENT_UPDATE_ENTRY_DATA,patientData);
        setResult(MainActivity.RESPONSE_UPDATE_DATA, returnIntent);
        finish();
    }
}
